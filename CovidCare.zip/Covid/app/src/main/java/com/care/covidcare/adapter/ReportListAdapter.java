package com.care.covidcare.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.care.covidcare.R;
import com.care.covidcare.models.Hospital;
import com.care.covidcare.models.ReportModel;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.textview.MaterialTextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/***
 * Hospital Report list adapter
 */
public class ReportListAdapter extends RecyclerView.Adapter<ReportListAdapter.MyViewHolder> {

    Context mContext;
    List<Hospital> mHospitalLists;

    public ReportListAdapter(Context mContext, List<Hospital> mHospitalLists) {
        this.mContext = mContext;
        this.mHospitalLists = mHospitalLists;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.report_itemlist,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        //set all values in views
        holder.mName.setText(mHospitalLists.get(position).getName());
        holder.mAddress.setText(mHospitalLists.get(position).getAddress());
        String date="Data as on "+new SimpleDateFormat("dd/MM/YY", Locale.getDefault()).format(Calendar.getInstance().getTime());
        holder.mUpdateDate.setText(date);
        holder.createChartView(mHospitalLists.get(position).getReportList());
        if (!holder.isShown){
            holder.mChartLinear.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mHospitalLists!=null?mHospitalLists.size():0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        MaterialTextView mName,mAddress,mUpdateDate;
        LinearLayout mChartLinear;
        AppCompatImageView mVisibleIcon;
        BarChart mBarChart;
        boolean isShown=false;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mName=itemView.findViewById(R.id.hName_report_item_list);
            mAddress=itemView.findViewById(R.id.hAddress_report_item_list);
            mUpdateDate=itemView.findViewById(R.id.date_report_item_list);
            mChartLinear=itemView.findViewById(R.id.barChart_linear_report_item_list);
            mVisibleIcon=itemView.findViewById(R.id.visible_img_report_item_list);
            mBarChart=itemView.findViewById(R.id.barChart_report_item_list);

            //listener on visible icon
            mVisibleIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //hide or unHide a chartView
                    if (isShown){
                        isShown=false;
                        mChartLinear.setVisibility(View.GONE);
                    }else{
                        isShown=true;
                        mChartLinear.setVisibility(View.VISIBLE);
                    }
                }
            });
        }

        /***
         * create a chart
         * @param reportModels list of chart data
         */
        public void createChartView(ArrayList<ReportModel> reportModels){
            mBarChart.setDrawBarShadow(false);
            mBarChart.setDrawValueAboveBar(true);
            mBarChart.setDrawGridBackground(false);
            mBarChart.setMaxVisibleValueCount(100);
            mBarChart.setFitBars(true);
            ArrayList<BarEntry> barEntries=new ArrayList<>();
            float i=0.5f;
            for (ReportModel report:reportModels) {
                barEntries.add(new BarEntry(i,report.getPoint()));
                i++;
            }
            if (barEntries.size()==0){
                Toast.makeText(mContext,"No data available",Toast.LENGTH_SHORT).show();
                return;
            }
            BarDataSet barDataSet=new BarDataSet(barEntries, "Characteristics");
            barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

            BarData data=new BarData(barDataSet);
            data.setBarWidth(0.7f);
            data.setDrawValues(true);
            mBarChart.setData(data);
            String[] chars={"Treatment","Safety cure","Staff","Cleaning","Recovery"};
            XAxis axis=mBarChart.getXAxis();
            axis.disableGridDashedLine();
            axis.setDrawGridLines(false);
            axis.setValueFormatter(new MyXAXis(chars));
            axis.setPosition(XAxis.XAxisPosition.BOTTOM);
            axis.setAxisMinimum(0f);
            axis.setGranularity(1);
            axis.setCenterAxisLabels(true);
        }

        private class MyXAXis extends ValueFormatter{
            String[] xValues;

            public MyXAXis(String[] xValues) {
                this.xValues = xValues;
            }

            @Override
            public String getFormattedValue(float value) {
                Log.d("xvalue", String.valueOf(value));
                int index=(int)value;
                switch (index){
                    case -1:
                        return "";
                    case 0:
                        return xValues[0];
                    case 1:
                        return xValues[1];
                    case 2:
                        return xValues[2];
                    case 3:
                        return xValues[3];
                    case 4:
                        return xValues[4];
                    default:
                        return "characteristic";
                }
            }

            @Override
            public String getBarLabel(BarEntry barEntry) {
                int index=(int)barEntry.getX();
                switch (index){
                    case 0:
                        return "";
                    case 1:
                        return xValues[0];
                    case 2:
                        return xValues[1];
                    case 3:
                        return xValues[2];
                    case 4:
                        return xValues[3];
                    case 5:
                        return xValues[4];
                    default:
                        return "characteristic";
                }
            }
        }
    }


}
