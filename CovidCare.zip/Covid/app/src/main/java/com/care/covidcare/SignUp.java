package com.care.covidcare;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.care.covidcare.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignUp extends AppCompatActivity {

    TextInputLayout mEmailLayout,mPassLayout,mCPassLayout,mUNameLayout;
    TextInputEditText mEmail,mPass,mCPass,mUName; //edittext for a inputs
    MaterialButton mSignUp; //signup button
    TextView mLogin; //login text
    final static String LOGKEY="Signup";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        mEmail=findViewById(R.id.edittext_email_signup);
        mEmailLayout=findViewById(R.id.textinput_email_signup);
        mPass=findViewById(R.id.edittext_pass_signup);
        mPassLayout=findViewById(R.id.textinput_pass_signup);
        mCPassLayout=findViewById(R.id.textinput_cpass_signup);
        mCPass=findViewById(R.id.edittext_cpass_signup);
        mUName=findViewById(R.id.edittext_uname_signup);
        mUNameLayout=findViewById(R.id.textinput_uname_signup);
        mSignUp=findViewById(R.id.registerbtn_signup);
        mLogin=findViewById(R.id.login_txt_signup);

        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginIntent();
            }
        });

        //listener on sign up button
        mSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()){
                    doSingUp(mEmail.getText().toString().trim()
                            ,mPass.getText().toString().trim()
                    ,mUName.getText().toString().trim());
                }
            }
        });
    }

    /***
     * a signup mechanism on with firebase
     * @param email a email string
     * @param pass a password string
     * @param name a name string
     */
    private void doSingUp(String email, String pass, final String name) {
        FirebaseAuth auth=FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(email, pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            FirebaseUser user=task.getResult().getUser();
                            if(!name.isEmpty()){
                                UserProfileChangeRequest.Builder profilechange=new UserProfileChangeRequest.Builder();
                                profilechange.setDisplayName(name);
                                user.updateProfile(profilechange.build()).addOnCompleteListener(
                                    new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                           addUserIndb();
                                        }
                                    }
                                )
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        e.printStackTrace();
                                        Log.d(LOGKEY,"User name changed failed,registration successful");
                                        addUserIndb();
                                    }
                                });
                            }else{
                                Log.d(LOGKEY,"No name found!Registration successful");
                                addUserIndb();
                            }
                        }else{
                            Log.d(LOGKEY,"Failed in onComplete"+task.getException().getMessage());
                            Toast.makeText(getApplicationContext(), "Registration failed,try again..!", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                        Log.d(LOGKEY,"Registration failed onfailure");
                        Toast.makeText(getApplicationContext(), "Registration failed,try again..!", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /***
     * check the all values if edittext is valid or ot
     * @return true if valid or false for not valid
     */
    private boolean validate(){
        if (mEmail.getText().toString().trim().isEmpty()){
            mEmailLayout.setError("Enter a Email id");
            return false;
        }else if (!Patterns.EMAIL_ADDRESS.matcher(mEmail.getText().toString().trim()).matches()){
            mEmailLayout.setError("Enter a Valid Email id");
            return  false;
        }
        if (mPass.getText().toString().trim().isEmpty()){
            mPassLayout.setError("Enter a Password");
            return false;
        }
        else if (mCPass.getText().toString().trim().isEmpty()){
            mCPassLayout.setError("Enter a ConfirmPassword");
            return false;
        }
        else if (!mPass.getText().toString().trim().equals(mCPass.getText().toString().trim())){
            mCPassLayout.setError("Password doesn't match,check it");
            return false;
        }
        return  true;
    }

    private void loginIntent(){
        Intent intent = new Intent(SignUp.this,Login.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void addUserIndb(){
        FirebaseUser fireuser=FirebaseAuth.getInstance().getCurrentUser();
        User user=new User();
        user.setEmailId(fireuser.getEmail());
        user.setName(fireuser.getDisplayName());
        user.setUid(fireuser.getUid());
        FirebaseFirestore.getInstance().collection("User")
                .add(user)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()){
                            Log.d(LOGKEY,"User data is inserted in db");
                            Toast.makeText(getApplicationContext(),"Registration successful",Toast.LENGTH_LONG).show();
                            loginIntent();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                e.printStackTrace();
                Log.e(LOGKEY,"User data is not inSereted in db");
                Toast.makeText(getApplicationContext(),"Registration unSuccessful",Toast.LENGTH_LONG).show();
            }
        });
    }
}