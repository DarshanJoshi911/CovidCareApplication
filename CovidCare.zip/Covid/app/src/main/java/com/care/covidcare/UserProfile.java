package com.care.covidcare;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.care.covidcare.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.squareup.picasso.Picasso;

public class UserProfile extends AppCompatActivity {

    MaterialButton mUpdate,mClose,mLogout;
    TextInputEditText mNameEdit;
    TextInputLayout mNameInput;
    RadioGroup mRadioGroup;
    MaterialRadioButton mMale,mFemale;
    ShapeableImageView mProfileImg;
    MaterialTextView healthScore;
    FirebaseUser user;
    SharedPreferences profilePrefences;
    private User mCurrentUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        mUpdate=findViewById(R.id.update_btn_profile);
        mClose=findViewById(R.id.close_btn_profile);
        mLogout=findViewById(R.id.logout_btn_profile);
        mNameEdit=findViewById(R.id.name_edit_profile);
        mNameInput=findViewById(R.id.name_input_profile);
        mRadioGroup=findViewById(R.id.radioGroup_profile);
        mMale=findViewById(R.id.male_radiobtn_profile);
        mFemale=findViewById(R.id.female_radiobtn_profile);
        mProfileImg=findViewById(R.id.user_image_profile);
        healthScore=findViewById(R.id.healthScore_text_profile);
        user= FirebaseAuth.getInstance().getCurrentUser();
        mCurrentUser= (User) getIntent().getSerializableExtra("user");
        setImage();
        setProfile();
        setListner();
    }


    private void setImage(){
        Uri url=user.getPhotoUrl();
        if (url==null){
            mProfileImg.setImageDrawable(getDrawable(R.drawable.ic_baseline_account_circle_24));
        }else{
            Picasso.get().load(url).into(mProfileImg);
        }
    }

    private void setProfile(){
        if (user.getDisplayName()!=null && !user.getDisplayName().isEmpty()){
            mNameEdit.setText(user.getDisplayName());
        }
        profilePrefences=getSharedPreferences("COVIDCARE",MODE_PRIVATE);
        String gender =profilePrefences.getString("gender",null);
        if (gender!=null){
            if (gender.equalsIgnoreCase("Male")){
                mMale.setChecked(true);
            }else{
                mFemale.setChecked(true);
            }
        }
        String previousScore=profilePrefences.getString("PreviousHealthScore",null);
        if (previousScore!=null){
            healthScore.setText("Your Health Score is "+previousScore);
        }
    }

    private void setListner(){
        mLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                if (FirebaseAuth.getInstance().getCurrentUser()==null){
                    Toast.makeText(getApplicationContext(),"Logout Successfully..!",Toast.LENGTH_LONG).show();
                    CallIntent();
                }else{
                    Log.d("signout","signOut unsuccessful,some wrong");
                    Toast.makeText(getApplicationContext(),"Logout UnSuccessfull,try again",Toast.LENGTH_LONG).show();
                }
            }
        });
        mClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=mNameEdit.getText().toString().trim();
                if (name.isEmpty() || name.equals("")){
                    mNameInput.setError("Enter Your Name");
                    return;
                }
                if (!name.equals(user.getDisplayName())){
                    UserProfileChangeRequest.Builder builder=new UserProfileChangeRequest.Builder();
                    builder.setDisplayName(name);
                    user.updateProfile(builder.build())
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    updateSharedPreference();
                                    Toast.makeText(getApplicationContext(),"Profile update Successfully..!",Toast.LENGTH_LONG).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    e.printStackTrace();
                                    Log.d("Profile","Profile update is failed "+e.getMessage());
                                    Toast.makeText(getApplicationContext(),"Profile Update failure..,try later",Toast.LENGTH_LONG).show();
                                    CallIntent();
                                }
                            });
                }
            }
        });

    }

    private void CallIntent(){
        Intent i=new Intent(UserProfile.this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    private void updateSharedPreference(){
        Editor editor=profilePrefences.edit();
        int id=mRadioGroup.getCheckedRadioButtonId();
        if (id==R.id.male_radiobtn_profile){
            editor.putString("gender","Male");
            editor.apply();
        }else if (id==R.id.female_radiobtn_profile){
            editor.putString("gender","Female");
            editor.apply();
        }
    }
}