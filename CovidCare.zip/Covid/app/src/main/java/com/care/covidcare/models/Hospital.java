package com.care.covidcare.models;

import java.util.ArrayList;

/***
 * a hospital model that contains all data of hospital
 */
public class Hospital {

    private String Name;
    private String Address;

    private ArrayList<ReportModel> reportList;

    public Hospital(String Name, String Address, ArrayList<ReportModel> reportList) {
        this.Name = Name;
        this.Address = Address;
        this.reportList = reportList;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        this.Address = address;
    }

    public ArrayList<ReportModel> getReportList() {
        return reportList;
    }

    public void setReportList(ArrayList<ReportModel> reportList) {
        this.reportList = reportList;
    }
}
