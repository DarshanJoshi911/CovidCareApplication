package com.care.covidcare;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Login extends AppCompatActivity {
    TextInputEditText email,pass; //editText
    TextInputLayout email_layout,pass_layout;
    MaterialButton login; //login buttton
    TextView forget,signUp;
    final String LOGKEY="Login";
    private FirebaseFirestore db=FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email=findViewById(R.id.edittext_email_login);
        pass=findViewById(R.id.edittext_pass_login);
        email_layout=findViewById(R.id.textinput_email_login);
        pass_layout=findViewById(R.id.textinput_pass_login);
        login=findViewById(R.id.loginbtn_login);
        forget=findViewById(R.id.forget_text_login);
        signUp=findViewById(R.id.signup_text_login);

        //listener on login button
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()){
                    tryLogin(email.getText().toString().trim(),pass.getText().toString().trim());
                }
            }
        });
        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"wait..",Toast.LENGTH_SHORT).show();
            }
        });
        //listener on signUp text
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,SignUp.class));
            }
        });
    }

    /***
     * login meahnism call in firebase
     * @param email a email string
     * @param password a password string
     */
    private void tryLogin(String email,String password) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Intent i=new Intent(Login.this,MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(i);
                        }else{
                            Toast.makeText(getApplicationContext(),"Login is failed",Toast.LENGTH_LONG).show();
                            Log.d(LOGKEY,"Login is failed,task is fail");
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                        Log.d(LOGKEY,"Login ids failed on"+e.getMessage());
                        Toast.makeText(getApplicationContext(),"Login is failed",Toast.LENGTH_LONG).show();
                    }
                });
    }


    /***
     * checking a values of editText is valid or not
     * @return true if values is valid otherwise false
     */
    private boolean validate(){
        if (email.getText().toString().isEmpty()){
            email_layout.setError("Enter a Email id");
            return false;
        }
        else if (pass.getText().toString().isEmpty()){
            pass_layout.setError("Enter a Password");
            return  false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString().trim()).matches()){
            email_layout.setError("Enter a valid Email-id");
            return  false;
        }
        return true;
    }

}