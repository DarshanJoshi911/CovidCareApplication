package com.care.covidcare.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.care.covidcare.R;

/***
 * to render a info fragment on info tab
 */
public class InfoFragment extends Fragment {

    WebView webView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_info,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //infoText=view.findViewById(R.id.info_text_info);
        webView=view.findViewById(R.id.webview_info);
        webView.loadDataWithBaseURL(null, getResources().getString(R.string.info),"text/html","utf-8",null);
        Log.d("info","working");
    }
}
