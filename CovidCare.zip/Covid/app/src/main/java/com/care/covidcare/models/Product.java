package com.care.covidcare.models;

import java.io.Serializable;

public class Product implements Serializable {

    private String name;
    private String productId;
    private int Price;
    private String imagePath;
    private String description;
    private int quantity;
    public Product() {
    }

    public Product(String name, String productId, int price, String imagePath, String description) {
        this.name = name;
        this.productId = productId;
        Price = price;
        this.imagePath = imagePath;
        this.description = description;
    }

    public Product(String name, String productId, int price, String imagePath, String description, int quantity) {
        this.name = name;
        this.productId = productId;
        Price = price;
        this.imagePath = imagePath;
        this.description = description;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
