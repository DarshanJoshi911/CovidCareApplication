package com.care.covidcare.adapter;

public interface ProductUpdationCart {

    public void increaseQuantity(int increase,int position);

    public void decreaseQuantity(int decrease,int position);

}
