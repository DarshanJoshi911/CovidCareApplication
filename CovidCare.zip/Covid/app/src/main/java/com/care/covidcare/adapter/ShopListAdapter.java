package com.care.covidcare.adapter;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.care.covidcare.ProductInfoActivity;
import com.care.covidcare.R;
import com.care.covidcare.models.Product;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ShopListAdapter extends RecyclerView.Adapter<ShopListAdapter.ShopViewHolder> {

    private Context mContext;
    private ArrayList<Product> mproductList;
    private Activity activity;
    public ShopListAdapter(Context context, ArrayList<Product> products,Activity activity){
        this.mContext=context;
        this.mproductList=products;
        this.activity=activity;
    }

    @NonNull
    @Override
    public ShopListAdapter.ShopViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ShopViewHolder(LayoutInflater.from(mContext).inflate(R.layout.shop_item_custom,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ShopListAdapter.ShopViewHolder holder, final int position) {
        String imgpath=mproductList.get(position).getImagePath();
        Picasso.get().load(Uri.parse(imgpath)).into(holder.imgView);
        holder.pTitle.setText(mproductList.get(position).getName());
        holder.pPrice.setText(String.valueOf(mproductList.get(position).getPrice())+" $");
        holder.mItemCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent info=new Intent(mContext, ProductInfoActivity.class);
                info.putExtra("product",mproductList.get(position));
                ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(activity,holder.mItemCard,holder.mItemCard.getTransitionName());
                mContext.startActivity(info,options.toBundle());
            }
        });
    }

    @Override
    public int getItemCount() {
        return mproductList!=null?mproductList.size():0;
    }

    static class ShopViewHolder extends RecyclerView.ViewHolder{

        private AppCompatImageView imgView;
        private MaterialTextView pTitle,pPrice;
        private MaterialCardView mItemCard;
        public ShopViewHolder(@NonNull View itemView) {
            super(itemView);
            imgView=itemView.findViewById(R.id.product_img_shop);
            pTitle=itemView.findViewById(R.id.product_title_shop);
            pPrice=itemView.findViewById(R.id.product_price_shop);
            mItemCard=itemView.findViewById(R.id.shop_item_card);
        }
    }


}
