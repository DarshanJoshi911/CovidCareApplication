package com.care.covidcare.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.care.covidcare.R;
import com.care.covidcare.adapter.ReportListAdapter;
import com.care.covidcare.models.Hospital;
import com.care.covidcare.models.ReportModel;

import java.util.ArrayList;
import java.util.List;

/***
 * to render report fragment on report tab
 */
public class ReportFragment extends Fragment {

    RecyclerView mRecyclerView;
    List<Hospital> hospitalList;
    ReportListAdapter adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_report,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRecyclerView=view.findViewById(R.id.recyclerview_report);
        createReportList();
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        mRecyclerView.setHasFixedSize(false);
        adapter=new ReportListAdapter(getContext(),hospitalList);
        mRecyclerView.setAdapter(adapter);
    }


    private void createReportList(){
        hospitalList=new ArrayList<>();

        ArrayList<ReportModel> reportModels1=new ArrayList<>();
        reportModels1.add(new ReportModel("Treatment",55f));
        reportModels1.add(new ReportModel("Safety cure",75f));
        reportModels1.add(new ReportModel("Staff",80f));
        reportModels1.add(new ReportModel("Cleaning",55f));
        reportModels1.add(new ReportModel("Recovery",67f));

        ArrayList<ReportModel> reportModels2=new ArrayList<>();
        reportModels2.add(new ReportModel("Treatment",43f));
        reportModels2.add(new ReportModel("Safety cure",59f));
        reportModels2.add(new ReportModel("Staff",45f));
        reportModels2.add(new ReportModel("Cleaning",72f));
        reportModels2.add(new ReportModel("Recovery",60f));

        ArrayList<ReportModel> reportModels3=new ArrayList<>();
        reportModels3.add(new ReportModel("Treatment",72f));
        reportModels3.add(new ReportModel("Safety cure",75f));
        reportModels3.add(new ReportModel("Staff",56f));
        reportModels3.add(new ReportModel("Cleaning",90f));
        reportModels3.add(new ReportModel("Recovery",78f));

        hospitalList.add(new Hospital("Shaliby Hospital","S.P. Road,Treatment Colony",reportModels1));
        hospitalList.add(new Hospital("Zydus Hospital","Sarkhej Road,Puna",reportModels2));
        hospitalList.add(new Hospital("CIMS Hopsital","Gandhinagar Marg,Stole",reportModels3));
    }
}
