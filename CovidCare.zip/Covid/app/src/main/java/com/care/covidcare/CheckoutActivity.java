package com.care.covidcare;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import com.care.covidcare.models.CardInfo;
import com.care.covidcare.models.Order;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class CheckoutActivity extends AppCompatActivity {

    private TextInputLayout mCardNoInput,mExpiryInput,mCvvInput;
    private TextInputEditText mCardNoEdit,mExpiryEdit,mCvvEdit;
    private MaterialButton payBtn;
    private ProgressBar mProgressbar;
    private MaterialCardView payCard,thankCard;
    private static Order mOrder;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
    private MaterialToolbar toolbar;
    private MaterialTextView toolbarText;
    private ShapeableImageView userImage;
    private AppCompatImageView cartImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        mOrder=(Order) getIntent().getSerializableExtra("order");
        if (mOrder==null){
            Toast.makeText(getApplicationContext(),"Order not found..,try again",Toast.LENGTH_LONG).show();
            onBackPressed();
        }
        toolbar=findViewById(R.id.toolbar_checkout);
        setSupportActionBar(toolbar);
        toolbarText=findViewById(R.id.title_text_toolbar);
        toolbarText.setText("Payment");
        userImage=findViewById(R.id.image_toolbar);
        cartImage=findViewById(R.id.cart_img_toolbar);
        userImage.setVisibility(View.GONE);
        cartImage.setVisibility(View.GONE);
        setIds();
        payBtn.setText("Pay "+mOrder.getTotalAmount()+" $");
        payBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mProgressbar.setVisibility(View.VISIBLE);
                if (validate()){
                    processOrder();
                }else{
                    mProgressbar.setVisibility(View.GONE);
                }
            }
        });
    }

    private void setIds(){
        mCardNoInput=findViewById(R.id.card_no_input);
        mCardNoEdit=findViewById(R.id.card_no_editText);
        mCvvInput=findViewById(R.id.cvv_input);
        mCvvEdit=findViewById(R.id.cvv_editText);
        mExpiryInput=findViewById(R.id.expiry_input);
        mExpiryEdit=findViewById(R.id.expiry_editText);
        payBtn=findViewById(R.id.pay_btn);
        payCard=findViewById(R.id.pay_card);
        thankCard=findViewById(R.id.thanks_card);
        mProgressbar=findViewById(R.id.progressbar_checkout);
    }

    private boolean validate(){
        boolean valid=true;
        String cardno=mCardNoEdit.getText().toString().trim();
        String expiry=mExpiryEdit.getText().toString().trim();
        String cvv=mCvvEdit.getText().toString().trim();

        if (cardno.isEmpty()){
            valid=false;
            mCardNoEdit.setError("Enter the card No");
        }
        if (expiry.isEmpty()){
            valid=false;
            mExpiryInput.setError("Enter the card Expiry date");
        }
        if (cvv.isEmpty()){
            valid=false;
            mCvvInput.setError("Enter the card CVV");
        }
        return valid;
    }

    private CardInfo saveCard(){
        return new CardInfo(mCardNoEdit.getText().toString().trim(),
                mExpiryEdit.getText().toString().trim(),
                Integer.parseInt(mCvvEdit.getText().toString().trim()));
    }

    private void processOrder(){
        mOrder.setCardinfo(saveCard());
        DocumentReference ref=db.collection("Order").document();
        mOrder.setOrderId(ref.getId());
        ref.set(mOrder)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            deleteCart();
                            orderSuccess();
                        }else{
                            task.getException().printStackTrace();
                            Log.d("Checkout","Task is unsuccessful,"+task.getException().getMessage());
                            Toast.makeText(getApplicationContext(),"Order not successful,Try again..!",Toast.LENGTH_LONG).show();
                            mProgressbar.setVisibility(View.GONE);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                e.printStackTrace();
                Log.d("Checkout","Exception ocuured, "+e.getMessage());
            }
        });
    }

    private void orderSuccess(){
        mProgressbar.setVisibility(View.GONE);
        payCard.setVisibility(View.GONE);
        thankCard.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }finally {
                    finish();
                }
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            Toast.makeText(getApplicationContext(),"You Cancel the payment",Toast.LENGTH_LONG).show();
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void deleteCart(){
        db.collection("Cart").document(mOrder.getCartId()).delete();
    }
}