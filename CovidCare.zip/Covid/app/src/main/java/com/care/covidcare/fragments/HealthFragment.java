package com.care.covidcare.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.care.covidcare.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/***
 * a health Fragment render on health tab
 */
public class HealthFragment extends Fragment implements View.OnClickListener {

    int health=98;
    MaterialTextView mPrevScore,mHealthScore,mSuggestText;
    MaterialButton mSubmitbtn,mResetbtn;
    LinearLayout mHealthLinear;
    TextInputLayout mNameInput;
    TextInputEditText mNameEditText;
    CardView mCard1,mCard2,mCard3,mCard4,mCardName;
    ChipGroup mCG1,mCG2,mCG3,mCG4;

    Chip mC_q1_1,mC_q1_2,mC_q1_3,mC_q1_4,mC_q1_5;
    Chip mC_q2_1,mC_q2_2,mC_q2_3,mC_q2_4,mC_q2_5;
    Chip mC_q3_1,mC_q3_2,mC_q3_3,mC_q3_4,mC_q3_5,mC_q3_6;
    Chip mC_q4_1,mC_q4_2,mC_q4_3,mC_q4_4,mC_q4_5;

    String Name="";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_health,container,false);
    }

     @Override
     public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
         setId(view);
         setListeners();
         resetHealth();
     }

     //change a background of chip
     private void changeSelectedChipBg(View view){
        view.setBackgroundColor(getContext().getResources().getColor(R.color.healthSelectedAnswer));
     }

     //update the health value
     private void updateHealth(int health){
        this.health=this.health-health;
     }

     //to show a health score view
     private void showHealthScore(){
        String s=Name+" your health score is "+health;
        mHealthScore.setText(s);
        if (mHealthLinear.getVisibility()==View.GONE)
            mHealthLinear.setVisibility(View.VISIBLE);
        setSuggestion();
     }

     //to reset health
     private void resetHealth(){
        this.health=98;
        if (mHealthLinear.getVisibility()==View.VISIBLE){
            mHealthLinear.setVisibility(View.GONE);
            mHealthScore.setText("");
        }
        if (mCardName.getVisibility()==View.VISIBLE) {
            mCardName.setVisibility(View.GONE);
            mNameEditText.setText("");
        }
        if (mSubmitbtn.getVisibility()==View.VISIBLE)
            mSubmitbtn.setVisibility(View.GONE);
        mCard2.setVisibility(View.GONE);
        mCard3.setVisibility(View.GONE);
        mCard4.setVisibility(View.GONE);
        mCard1.setVisibility(View.VISIBLE);
        mPrevScore.setVisibility(View.GONE);
     }

     //to get name if required
     private void enableNameInput(){
        FirebaseUser fuser= FirebaseAuth.getInstance().getCurrentUser();
        if (fuser!=null){
            Name=fuser.getDisplayName();
        }
        if (Name.isEmpty() || Name.trim().equals("")){
            mCardName.setVisibility(View.VISIBLE);
        }
        mSubmitbtn.setVisibility(View.VISIBLE);
     }

     //set listeners on button,chips
     private void setListeners(){
        mSubmitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCardName.getVisibility()==View.VISIBLE){
                    if (mNameEditText.getText().toString().trim().isEmpty()|| mNameEditText.getText().toString().trim().equals("")){
                        mNameInput.setError("Enter a Valid Name");
                    }
                    else{
                      Name=mNameEditText.getText().toString().trim();
                      mHealthLinear.setVisibility(View.VISIBLE);
                      showHealthScore();
                    }
                }
                else{
                    mHealthLinear.setVisibility(View.VISIBLE);
                    showHealthScore();
                }
            }
        });
        mResetbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetHealth();
            }
        });

        mC_q1_1.setOnClickListener(this);
        mC_q1_2.setOnClickListener(this);
        mC_q1_3.setOnClickListener(this);
        mC_q1_4.setOnClickListener(this);
        mC_q1_5.setOnClickListener(this);
        mC_q2_1.setOnClickListener(this);
        mC_q2_2.setOnClickListener(this);
        mC_q2_3.setOnClickListener(this);
        mC_q2_4.setOnClickListener(this);
        mC_q2_5.setOnClickListener(this);
        mC_q3_1.setOnClickListener(this);
        mC_q3_2.setOnClickListener(this);
        mC_q3_3.setOnClickListener(this);
        mC_q3_4.setOnClickListener(this);
        mC_q3_5.setOnClickListener(this);
        mC_q3_6.setOnClickListener(this);
        mC_q4_1.setOnClickListener(this);
        mC_q4_2.setOnClickListener(this);
        mC_q4_3.setOnClickListener(this);
        mC_q4_4.setOnClickListener(this);
        mC_q4_5.setOnClickListener(this);
     }

     //set all view id's
     private void setId(View view){
        mPrevScore=view.findViewById(R.id.prev_healthscore_txt_health);
        mHealthScore=view.findViewById(R.id.healthscore_txt_health);
        mSubmitbtn=view.findViewById(R.id.submit_btn_health);
        mResetbtn=view.findViewById(R.id.reset_btn_health);
        mHealthLinear=view.findViewById(R.id.health_score_linear_health);
        mNameEditText=view.findViewById(R.id.edittext_name_health);
        mNameInput=view.findViewById(R.id.inputlayout_name_health);
        mSuggestText=view.findViewById(R.id.healthSuggestion_txt_health);

        mCard1=view.findViewById(R.id.card_1_que_health);
        mCard2=view.findViewById(R.id.card_2_que_health);
        mCard3=view.findViewById(R.id.card_3_que_health);
        mCard4=view.findViewById(R.id.card_4_que_health);
        mCardName=view.findViewById(R.id.name_card_health);

        mCG1=view.findViewById(R.id.chips_1_que_health);
        mCG2=view.findViewById(R.id.chips_second_question_health);
        mCG3=view.findViewById(R.id.chips_third_que_health);
        mCG4=view.findViewById(R.id.chips_fourth_que_health);

        mC_q1_1=view.findViewById(R.id.chip_first_first_ans_health);
        mC_q1_2=view.findViewById(R.id.chip_first_second_ans_health);
        mC_q1_3=view.findViewById(R.id.chip_first_third_ans_health);
        mC_q1_4=view.findViewById(R.id.chip_first_fourth_ans_health);
        mC_q1_5=view.findViewById(R.id.chip_first_fifth_ans_health);
        mC_q2_1=view.findViewById(R.id.chip_second_first_ans_health);
        mC_q2_2=view.findViewById(R.id.chip_second_second_ans_health);
        mC_q2_3=view.findViewById(R.id.chip_second_third_ans_health);
        mC_q2_4=view.findViewById(R.id.chip_second_fourth_ans_health);
        mC_q2_5=view.findViewById(R.id.chip_second_fifth_ans_health);
        mC_q3_1=view.findViewById(R.id.chip_third_first_ans_health);
        mC_q3_2=view.findViewById(R.id.chip_third_second_ans_health);
        mC_q3_3=view.findViewById(R.id.chip_third_third_ans_health);
        mC_q3_4=view.findViewById(R.id.chip_third_fourth_ans_health);
        mC_q3_5=view.findViewById(R.id.chip_third_fifth_ans_health);
        mC_q3_6=view.findViewById(R.id.chip_third_six_ans_health);
        mC_q4_1=view.findViewById(R.id.chip_fourth_first_ans_health);
        mC_q4_2=view.findViewById(R.id.chip_fourth_second_ans_health);
        mC_q4_3=view.findViewById(R.id.chip_fourth_third_ans_health);
        mC_q4_4=view.findViewById(R.id.chip_fourth_fourth_ans_health);
        mC_q4_5=view.findViewById(R.id.chip_fourth_fifth_ans_health);
     }

     //show the next question
    private void showCard(int no){
        switch (no){
            case 2:
                mCard2.setVisibility(View.VISIBLE);
                break;
            case 3:
                mCard3.setVisibility(View.VISIBLE);
                break;
            case 4:
                mCard4.setVisibility(View.VISIBLE);
                break;
        }
    }

    //set suggestion for according  a health
    private void setSuggestion(){
        if (health>90){
            mSuggestText.setText("Your Healthy is very good,but don't forget to wear a face mask.");
            mSuggestText.setTextColor(Color.GREEN);
        }
        else if (health>85){
            mSuggestText.setText("Your Health is good,but don't forget to take care and follow social distance");
            mSuggestText.setTextColor(Color.GREEN);
        }else if (health>60 && health<85){
            mSuggestText.setText("Your health is worrying,if you feeling  not a well then immediately meet a doctor and take a medicine");
            mSuggestText.setTextColor(Color.YELLOW);
        }else if (health>45 && health<60){
            mSuggestText.setText("You Health is critical,get a medical treatment now,Call on Emergency number for further references");
            mSuggestText.setTextColor(Color.RED);
        }
        else if (health<45){
            mSuggestText.setText("Your Situation is critical,please call on a Emergency number to get a immediate treatment");
            mSuggestText.setTextColor(Color.RED);
        }
    }

    //a listener for chips
    @Override
    public void onClick(View v) {
        changeSelectedChipBg(v);
        switch (v.getId()) {
            case R.id.chip_first_first_ans_health:
                updateHealth(5);
                showCard(2);
                break;
            case R.id.chip_first_second_ans_health:
                updateHealth(5);
                showCard(2);
                break;
            case R.id.chip_first_third_ans_health:
                updateHealth(5);
                showCard(2);
                break;
            case R.id.chip_first_fourth_ans_health:
                updateHealth(5);
                showCard(2);
                break;
            case R.id.chip_first_fifth_ans_health:
                showCard(3);
                break;
            case R.id.chip_second_first_ans_health:
                updateHealth(10);
                showCard(3);
                break;
            case R.id.chip_second_second_ans_health:
                updateHealth(10);
                showCard(3);
                break;
            case R.id.chip_second_third_ans_health:
                updateHealth(10);
                showCard(3);
                break;
            case R.id.chip_second_fourth_ans_health:
                updateHealth(10);
                showCard(3);
                break;
            case R.id.chip_second_fifth_ans_health:
                showCard(3);
                break;
            case R.id.chip_third_first_ans_health:
                updateHealth(10);
                showCard(4);
                break;
            case R.id.chip_third_second_ans_health:
                updateHealth(10);
                showCard(4);
                break;
            case R.id.chip_third_third_ans_health:
                updateHealth(10);
                showCard(4);
                break;
            case R.id.chip_third_fourth_ans_health:
                updateHealth(10);
                showCard(4);
                break;
            case R.id.chip_third_fifth_ans_health:
                updateHealth(10);
                showCard(4);
                break;
            case R.id.chip_third_six_ans_health:
                showCard(4);
                break;
            case R.id.chip_fourth_first_ans_health:
                updateHealth(5);
                enableNameInput();
                break;
            case R.id.chip_fourth_second_ans_health:
                updateHealth(5);
                enableNameInput();
                break;
            case R.id.chip_fourth_third_ans_health:
                updateHealth(5);
                enableNameInput();
                break;
            case R.id.chip_fourth_fourth_ans_health:
                updateHealth(5);
                enableNameInput();
                break;
            case R.id.chip_fourth_fifth_ans_health:
                enableNameInput();
                break;
        }
    }
}
