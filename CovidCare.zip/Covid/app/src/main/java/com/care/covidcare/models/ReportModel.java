package com.care.covidcare.models;

/***
 * a data model for a hospital report chart
 */
public class ReportModel {
    private String characteristic;
    private float point;

    public ReportModel(String characteristic, float point) {
        this.characteristic = characteristic;
        this.point = point;
    }

    public String getCharacteristic() {
        return characteristic;
    }

    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

    public float getPoint() {
        return point;
    }

    public void setPoint(float point) {
        this.point = point;
    }
}
