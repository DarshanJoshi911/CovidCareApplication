package com.care.covidcare;

import com.google.android.material.tabs.TabLayout;

class CustomTabView extends TabLayout.Tab {


}
