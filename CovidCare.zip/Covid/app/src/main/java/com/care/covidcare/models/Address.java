package com.care.covidcare.models;

public class Address {

    private String houseNo;
    private String street;
    private String postalCode;
    private String city;
    private String state;
    private String name;
    private String mobileNo;
    private String emailId;

    public Address() {
    }

    public Address(String houseNo, String street, String postalCode, String city, String state, String name, String mobileNo, String emailId) {
        this.houseNo = houseNo;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
        this.state = state;
        this.name = name;
        this.mobileNo = mobileNo;
        this.emailId = emailId;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
}
