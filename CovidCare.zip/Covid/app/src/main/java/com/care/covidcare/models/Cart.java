package com.care.covidcare.models;

import java.io.Serializable;
import java.util.List;

public class Cart implements Serializable {

    private String cartId;
    private String uid;
    private int totalItem;
    private int totalAmount;
    private List<String> productQuantity;
    private List<String> productId;
    public Cart() {
    }

    public Cart(String cartId, String uid, int totalItem, int totalAmount, List<String> productId) {
        this.cartId = cartId;
        this.uid = uid;
        this.totalItem = totalItem;
        this.totalAmount = totalAmount;
        this.productId = productId;
    }

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getTotalItem() {
        return totalItem;
    }

    public void setTotalItem(int totalItem) {
        this.totalItem = totalItem;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<String> getProductId() {
        return productId;
    }

    public void setProductId(List<String> productId) {
        this.productId = productId;
    }

    public List<String> getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(List<String> productQuantity) {
        this.productQuantity = productQuantity;
    }
}
