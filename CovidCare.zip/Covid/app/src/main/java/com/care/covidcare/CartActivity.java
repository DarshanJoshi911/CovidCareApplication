package com.care.covidcare;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.care.covidcare.adapter.CartListAdapter;
import com.care.covidcare.adapter.ProductUpdationCart;
import com.care.covidcare.models.Address;
import com.care.covidcare.models.Cart;
import com.care.covidcare.models.Order;
import com.care.covidcare.models.Product;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CartActivity extends AppCompatActivity implements ProductUpdationCart {

    private RecyclerView recyclerView;
    private static ArrayList<Product> productsList;
    private MaterialButton buyBtn;
    private MaterialTextView mTotalQuantityText, mTotalPriceText;
    private CartListAdapter mAdapter;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private static final String LOGNAME = "CartActivity";
    private static int mTotalPrice = 0;
    private static int mTotalQuantity = 0;
    private static Cart mCart;
    private int[] productQuantity;

    //address and contact details
    private TextInputLayout mHouseInput,mStreetInput,mPostalInput,mCityInput,mStateInput,mPersonNameInput,mMobileInput,mEmailIdInput;
    private TextInputEditText mHouseEdit,mStreetEdit,mPostalEdit,mCityEdit,mStateEdit,mPersonNameEdit,mMobileEdit,mEmailIdEdit;
    private MaterialButton mCheckout;
    private ScrollView mAdressLayout;
    private RelativeLayout mCartLayout;

    private MaterialToolbar toolbar;
    private MaterialTextView toolbarText;
    private ShapeableImageView userImage;
    private AppCompatImageView cartImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        setIds();
        LinearLayoutManager manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
        fetchList();
        addListener();
    }

    private void addListener() {
        buyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setValues();
                mCartLayout.setVisibility(View.GONE);
                mAdressLayout.setVisibility(View.VISIBLE);
            }
        });
        mCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCheckout.setClickable(false);
                if (validate()){
                    makeOrder();
                }
                mCheckout.setClickable(true);
            }
        });
        userImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent user=new Intent(CartActivity.this,UserProfile.class);
                ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(CartActivity.this, userImage, userImage.getTransitionName());
                startActivity(user,options.toBundle());
                finish();
            }
        });
    }

    private void fetchList() {
        if (user == null) {
            Log.d(LOGNAME, "user value found null");
            Toast.makeText(getApplicationContext(), "You are logged out,Please log in again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(CartActivity.this, Login.class));
            finish();
            return;
        }
        db.collection("Cart")
                .whereEqualTo("uid", user.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot snapshot : task.getResult()) {
                                mCart = snapshot.toObject(Cart.class);
                            }
                            if (mCart==null) {
                                cartEmpty();
                            return;}
                            List<String> productId= mCart.getProductId();
                            for (int i = 0; i < productId.size(); i++) {
                                fetchProduct(productId.get(i),i);
                            }
                            mTotalQuantity=mCart.getTotalItem();
                            mTotalPrice=mCart.getTotalAmount();
                            updatePriceAndItem();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                        Log.d(LOGNAME, "getList error, " + e.getMessage());
                        Toast.makeText(getApplicationContext(), "Error on request", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void setRecyclerView() {
        mAdapter = new CartListAdapter(CartActivity.this, productsList, this);
        recyclerView.setAdapter(mAdapter);
    }

    private void updatePriceAndItem() {
        mTotalQuantityText.setText(String.valueOf(mTotalQuantity));
        mTotalPriceText.setText(String.valueOf(mTotalPrice) + " $");
        mCart.setTotalAmount(mTotalPrice);
        mCart.setTotalItem(mTotalQuantity);
    }

    @Override
    public void increaseQuantity(int increase, int position) {
        productsList.get(position).setQuantity(productsList.get(position).getQuantity() + 1);
        mTotalQuantity = mTotalQuantity + 1;
        mTotalPrice = mTotalPrice + (productsList.get(position).getPrice());
        updatePriceAndItem();
    }

    @Override
    public void decreaseQuantity(int decrease, int position) {
        productsList.get(position).setQuantity(productsList.get(position).getQuantity() - 1);
        mTotalQuantity = mTotalQuantity - 1;
        mTotalPrice = mTotalPrice - (productsList.get(position).getPrice());
        updatePriceAndItem();
    }

    private void fetchProduct(final String productId,final int pos) {
        Log.d(LOGNAME,"ProductId "+productId);
        db.collection("Product")
                .document(productId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            productsList=new ArrayList<>();
                            DocumentSnapshot snap=task.getResult();
                            Product p=snap.toObject(Product.class);
                            p.setQuantity(1);
                            productsList.add(p);
                            if (mAdapter==null) setRecyclerView();
                        } else {
                            task.getException().printStackTrace();
                            Log.d(LOGNAME, "task is unsuccessful for productId:- " + productId + " reason " + task.getException().getMessage());
                        }
                    }
                });
    }

    private void setIds(){
        recyclerView = findViewById(R.id.recyclerView_cart);
        buyBtn = findViewById(R.id.buy_btn_cart);
        mTotalPriceText = findViewById(R.id.total_price_textView_cart);
        mTotalQuantityText = findViewById(R.id.total_item_textView_cart);
        mHouseInput=findViewById(R.id.house_input_cart);
        mHouseEdit=findViewById(R.id.house_editText_cart);
        mStreetInput=findViewById(R.id.street_input_cart);
        mStreetEdit=findViewById(R.id.street_ediText_cart);
        mPostalInput=findViewById(R.id.pincode_input_cart);
        mPostalEdit=findViewById(R.id.pincode_editText_cart);
        mCityInput=findViewById(R.id.city_input_cart);
        mCityEdit=findViewById(R.id.city_editText_cart);
        mStateInput=findViewById(R.id.state_input_cart);
        mStateEdit=findViewById(R.id.state_editText_cart);
        mPersonNameInput=findViewById(R.id.name_input_cart);
        mPersonNameEdit=findViewById(R.id.name_ediText_cart);
        mMobileInput=findViewById(R.id.mobile_input_cart);
        mMobileEdit=findViewById(R.id.mobile_editText_Cart);
        mEmailIdInput=findViewById(R.id.email_input_cart);
        mEmailIdEdit=findViewById(R.id.email_editText_Cart);
        mCheckout=findViewById(R.id.checkout_btn_cart);
        mAdressLayout=findViewById(R.id.address_info_cart);
        mCartLayout=findViewById(R.id.cart_info_cart);
        toolbar=findViewById(R.id.toolbar_cart);
        setSupportActionBar(toolbar);
        toolbarText=findViewById(R.id.title_text_toolbar);
        toolbarText.setText("Your Cart");
        userImage=findViewById(R.id.image_toolbar);
        cartImage=findViewById(R.id.cart_img_toolbar);
        userImage.setVisibility(View.VISIBLE);
        cartImage.setVisibility(View.GONE);
    }

    private boolean validate(){
        boolean valid=true;
        String hosue=mHouseEdit.getText().toString().trim();
        String street=mStreetEdit.getText().toString().trim();
        String postal=mPostalEdit.getText().toString().trim();
        String city=mCityEdit.getText().toString().trim();
        String state=mStateEdit.getText().toString().trim();
        String name=mPersonNameEdit.getText().toString().trim();
        String mobile=mMobileEdit.getText().toString().trim();
        String email=mEmailIdEdit.getText().toString().trim();

        if (hosue.isEmpty()){
            valid=false;
            mHouseInput.setError("Please Enter a House no");
        }

        if (street.isEmpty()){
            valid=false;
            mStreetInput.setError("Street Address required");
        }

        if (postal.isEmpty()){
            valid=false;
            mPostalInput.setError("PostalCode required");
        }
        if (city.isEmpty()){
            valid=false;
            mCityInput.setError("Please Enter a City name");
        }
        if (state.isEmpty()){
            valid=false;
            mStateInput.setError("Please Enter a State name");
        }
        if (name.isEmpty()){
            valid=false;
            mPersonNameInput.setError("Your name is required");
        }
        if (mobile.isEmpty()){
            valid=false;
            mMobileInput.setError("Your mobile No is required");
        }
        if (email.isEmpty()){
            valid=false;
            mEmailIdInput.setError("Please Enter a Email id");
        }else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            valid=false;
            mEmailIdInput.setError("Please Enter valid Email-id");
        }
        return valid;
    }

    private void makeOrder(){
        Address address=new Address(mHouseEdit.getText().toString().trim(),
            mStreetEdit.getText().toString().trim(),
            mPostalEdit.getText().toString().trim(),
            mCityEdit.getText().toString().trim(),
            mStateEdit.getText().toString().trim(),
            mPersonNameEdit.getText().toString().trim(),
            mMobileEdit.getText().toString().trim(),
            mEmailIdEdit.getText().toString().trim());
        Order order=new Order();
        order.setProductId(mCart.getProductId());
        order.setTotalAmount(mCart.getTotalAmount());
        order.setTotalQuantity(mCart.getTotalItem());
        order.setPurchaseDate(Calendar.getInstance().getTime());
        order.setUid(user.getUid());
        order.setCartId(mCart.getCartId());
        Intent checkout=new Intent(CartActivity.this,CheckoutActivity.class);
        checkout.putExtra("order",order);
        startActivity(checkout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setValues(){
        mEmailIdEdit.setText(user.getEmail());
        mPersonNameEdit.setText(user.getDisplayName());
    }

    private void cartEmpty(){
        Toast.makeText(getApplicationContext(),"Your cart is empty",Toast.LENGTH_LONG).show();
        onBackPressed();
    }
}