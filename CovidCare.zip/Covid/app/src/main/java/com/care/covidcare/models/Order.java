package com.care.covidcare.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Order implements Serializable{

    private String orderId;
    private int totalQuantity;
    private int totalAmount;
    private List<String> productId;
    private String timeStamp;
    private CardInfo cardinfo;
    private Date purchaseDate;
    private String uid;
    private String cartId;

    public Order() {
    }

    public Order(String orderId, int totalQuantity, int totalAmount, List<String> productId, String timeStamp, CardInfo cardinfo, Date purchaseDate, String uid) {
        this.orderId = orderId;
        this.totalQuantity = totalQuantity;
        this.totalAmount = totalAmount;
        this.productId = productId;
        this.timeStamp = timeStamp;
        this.cardinfo = cardinfo;
        this.purchaseDate = purchaseDate;
        this.uid = uid;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<String> getProductId() {
        return productId;
    }

    public void setProductId(List<String> productId) {
        this.productId = productId;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public CardInfo getCardinfo() {
        return cardinfo;
    }

    public void setCardinfo(CardInfo cardinfo) {
        this.cardinfo = cardinfo;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }
}
