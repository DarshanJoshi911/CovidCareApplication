package com.care.covidcare.models;

import java.io.Serializable;

public class User implements Serializable {

    private String uid;
    private String name;
    private String emailId;
    private int gender;

    public User() {
    }

    public User(String uid, String name, String emailId, int gender) {
        this.uid = uid;
        this.name = name;
        this.emailId = emailId;
        this.gender = gender;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

}
