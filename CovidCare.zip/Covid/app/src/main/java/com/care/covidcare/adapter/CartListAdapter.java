package com.care.covidcare.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.care.covidcare.CartActivity;
import com.care.covidcare.R;
import com.care.covidcare.models.Product;
import com.google.android.material.textview.MaterialTextView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.ProductHolder> {

    private Context mContext;
    private ArrayList<Product> productsList;
    private ProductUpdationCart productUpdationCart;

    public CartListAdapter(Context context,ArrayList<Product> productsList,ProductUpdationCart productUpdationCart){
        this.mContext=context;
        this.productsList=productsList;
        this.productUpdationCart=productUpdationCart;
    }
    @NonNull
    @Override
    public CartListAdapter.ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ProductHolder(LayoutInflater.from(mContext).inflate(R.layout.cart_list_custom_view,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CartListAdapter.ProductHolder holder, int position) {
        String imgpath=productsList.get(position).getImagePath();
        Picasso.get().load(Uri.parse(imgpath)).into(holder.productImg);
        holder.pTitle.setText(productsList.get(position).getName());
        holder.pPrice.setText(String.valueOf(productsList.get(position).getPrice()));
        holder.pQuantity.setText(String.valueOf(productsList.get(position).getQuantity()));
    }

    @Override
    public int getItemCount() {
        return productsList!=null?productsList.size():0;
    }

    public void updateList(Product p){
        productsList.add(p);
        notifyDataSetChanged();
    }

    public class ProductHolder extends RecyclerView.ViewHolder{

        AppCompatImageView productImg;
        AppCompatImageButton plusBtn,minusBtn;
        MaterialTextView pTitle,pPrice,pQuantity;
        int position;

        public ProductHolder(@NonNull View itemView) {
            super(itemView);
            productImg=itemView.findViewById(R.id.product_img_cart);
            plusBtn=itemView.findViewById(R.id.add_imgbtn_cart);
            minusBtn=itemView.findViewById(R.id.minus_imgbtn_cart);
            pTitle=itemView.findViewById(R.id.product_title_cart);
            pPrice=itemView.findViewById(R.id.product_price_cart);
            pQuantity=itemView.findViewById(R.id.quantity_textView_cart);
            plusBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int q=Integer.parseInt(pQuantity.getText().toString());
                    if (q>5){
                        Toast.makeText(mContext,"Max purchase limit reached",Toast.LENGTH_SHORT).show();
                    }else{
                        productUpdationCart.increaseQuantity(1,position);
                        pQuantity.setText(String.valueOf(q+1));
                    }
                }
            });
            minusBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int q=Integer.parseInt(pQuantity.getText().toString());
                    if (q==1){
                        Toast.makeText(mContext,"Minimum 1 quantity required",Toast.LENGTH_SHORT).show();
                    }else{
                        productUpdationCart.decreaseQuantity(1,position);
                        pQuantity.setText(String.valueOf(q-1));
                    }
                }
            });
        }

        public void setPosition(int val){
            position=val;
        }

    }
}
