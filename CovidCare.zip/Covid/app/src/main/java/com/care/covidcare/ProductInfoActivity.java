package com.care.covidcare;

import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import com.care.covidcare.models.Cart;
import com.care.covidcare.models.Product;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductInfoActivity extends AppCompatActivity {

    private static Product mProduct;
    private AppCompatImageView mProductImg;
    private MaterialTextView mTitle,mPrice,mDesc;
    private MaterialButton addBtn;
    private MaterialToolbar toolbar;
    private MaterialTextView toolbarText;
    private ShapeableImageView userImage;
    private AppCompatImageView cartImage;
    private static final String LOGNAME="ProductInfo";
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_info);
        mProduct= (Product) getIntent().getSerializableExtra("product");
        if (mProduct==null){
            Log.d(LOGNAME,"Product object is null");
            Toast.makeText(getApplicationContext(),"Something went wrong..!",Toast.LENGTH_LONG).show();
            onBackPressed();
        }
        setIds();
        addListener();
        setProductInfo();
    }

    private void addListener(){
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBtn.setClickable(false);
                addProductInCart();
            }
        });
        cartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cart=new Intent(ProductInfoActivity.this,CartActivity.class);
                ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(ProductInfoActivity.this,cartImage,cartImage.getTransitionName());
                startActivity(cart,options.toBundle());
            }
        });
    }

    private void setIds(){
        mProductImg=findViewById(R.id.product_img_product_info);
        mTitle=findViewById(R.id.title_textView_product_info);
        mPrice=findViewById(R.id.price_textView_product_info);
        mDesc=findViewById(R.id.desc_textView_product_info);
        addBtn=findViewById(R.id.add_cart_btn_product_info);
        toolbar=findViewById(R.id.toolbar_product_info);
        setSupportActionBar(toolbar);
        toolbarText=findViewById(R.id.title_text_toolbar);
        toolbarText.setText(mProduct.getName());
        userImage=findViewById(R.id.image_toolbar);
        cartImage=findViewById(R.id.cart_img_toolbar);
        userImage.setVisibility(View.VISIBLE);
        cartImage.setVisibility(View.VISIBLE);
    }

    private void addProductInCart(){
        if (user==null){
            Toast.makeText(getApplicationContext(),"Please login first",Toast.LENGTH_LONG).show();
            startActivity(new Intent(ProductInfoActivity.this,Login.class));
            finish();
            return;
        }
        final Cart cart=new Cart();
        cart.setUid(user.getUid());
        cart.setTotalItem(1);
        cart.setTotalAmount(mProduct.getPrice());
        List<String> productid = new ArrayList<>();
        productid.add(mProduct.getProductId());
        cart.setProductId(productid);

        db.collection("Cart")
                .whereEqualTo("uid",user.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        boolean inforloop=false;
                        if (task.isSuccessful()){
                            Log.d(LOGNAME,"Task is successful");
                            for (QueryDocumentSnapshot snapshot:task.getResult()){
                                inforloop=true;
                                Cart cart1=snapshot.toObject(Cart.class);
                                List<String> productId=cart1.getProductId();
                                boolean isProductadd=false;
                                for (int i=0;i<productId.size();i++){
                                    if (productId.get(i).equals(mProduct.getProductId())){
                                        isProductadd=true;
                                    }
                                }
                                if (!isProductadd){
                                    productId.add(mProduct.getProductId());
                                    cart1.setProductId(productId);
                                    cart1.setTotalAmount(cart1.getTotalAmount()+mProduct.getPrice());
                                    cart1.setTotalItem(cart1.getTotalItem()+1);
                                    Map<String,Object> maps=new HashMap<>();
                                    maps.put("productId",productId);
                                    maps.put("totalAmount",cart1.getTotalAmount());
                                    maps.put("totalItem",cart1.getTotalItem());
                                    db.collection("Cart").document(cart1.getCartId()).update(maps)
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            addBtn.setClickable(true);
                                            e.printStackTrace();
                                            Log.d(LOGNAME,"Cart update failed, "+e.getMessage());
                                            Toast.makeText(getApplicationContext(),"Cart updation failed..",Toast.LENGTH_LONG).show();
                                        }
                                    });
                                }else{
                                    addBtn.setClickable(true);
                                    Log.d(LOGNAME,"Product is alreday in cart");
                                    Toast.makeText(getApplicationContext(),"Product is already added in cart,Go in cart",Toast.LENGTH_LONG).show();
                                    return;
                                }
                            }
                            if (!inforloop){
                                DocumentReference ref=db.collection("Cart").document();
                                cart.setCartId(ref.getId());
                                ref.set(cart)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()){
                                                    Log.d(LOGNAME,"Product add in cart");
                                                    Toast.makeText(getApplicationContext(),"Product is added in cart",Toast.LENGTH_LONG).show();
                                                }
                                                addBtn.setClickable(true);
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                addBtn.setClickable(true);
                                                e.printStackTrace();
                                                Log.d(LOGNAME,"Cart update failed, "+e.getMessage());
                                                Toast.makeText(getApplicationContext(),"Product is not added in cart",Toast.LENGTH_LONG).show();
                                            }
                                        });
                            }
                        }else{
                            Log.d(LOGNAME,"Task is unsuccessful");
                            DocumentReference ref=db.collection("Cart").document();
                            cart.setCartId(ref.getId());
                            ref.set(cart)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                Log.d(LOGNAME,"Product add in cart");
                                                Toast.makeText(getApplicationContext(),"Product is added in cart",Toast.LENGTH_LONG).show();
                                            }
                                            addBtn.setClickable(true);
                                        }
                                    })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    addBtn.setClickable(true);
                                    e.printStackTrace();
                                    Log.d(LOGNAME,"Cart update failed, "+e.getMessage());
                                    Toast.makeText(getApplicationContext(),"Product is not added in cart",Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                addBtn.setClickable(true);
                e.printStackTrace();
                Log.d(LOGNAME,"task failed..,"+e.getMessage());
                Toast.makeText(getApplicationContext(),"Some error,try again..",Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setProductInfo(){
        Picasso.get().load(Uri.parse(mProduct.getImagePath())).into(mProductImg);
        mTitle.setText(mProduct.getName());
        mPrice.setText(String.valueOf(mProduct.getPrice())+" $");
        mDesc.setText(mProduct.getDescription());
    }
}