package com.care.covidcare;

import android.app.ActivityOptions;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.airbnb.lottie.LottieAnimationView;
import com.care.covidcare.fragments.HealthFragment;
import com.care.covidcare.fragments.InfoFragment;
import com.care.covidcare.fragments.ReportFragment;
import com.care.covidcare.fragments.ShopFragment;
import com.care.covidcare.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

/***
 * The main Activity of Appication
 */
public class MainActivity extends AppCompatActivity {

    MaterialToolbar mToolbar; //to store a app bar
    TabLayout mTabLayout; //a tablayout holder
    MaterialTextView mToolbarTitle; //a toolbarTitle object
    ShapeableImageView mToolbarImage; //a toolbarImage(ProfileImage)
    ViewPager mViewPager; //ViewPager to show fragments
    MyViewpagerAdapter mViewpagerAdapter; //custom viewpager adapter
    AppCompatImageView cartImg;
    private User mCurrentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //set id's
        mToolbar=findViewById(R.id.toolbar_main);
        setSupportActionBar(mToolbar);
        mToolbarTitle=findViewById(R.id.title_text_toolbar);
        mToolbarImage=findViewById(R.id.image_toolbar);
        cartImg=findViewById(R.id.cart_img_toolbar);
        mTabLayout=findViewById(R.id.tab_main);
        mViewPager=findViewById(R.id.viepager_main);
        mTabLayout.setupWithViewPager(mViewPager);
        fetchUser();
        mViewpagerAdapter=new MyViewpagerAdapter(getSupportFragmentManager(),FragmentPagerAdapter.POSITION_UNCHANGED);
        mViewPager.setAdapter(mViewpagerAdapter);
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                //changing  a toolbar title according the tab selected
                switch (tab.getPosition()){
                    case 0:
                        mToolbarTitle.setText("COVID-19 Information");
                        break;
                    case 1:
                        mToolbarTitle.setText("Health Score");
                        break;
                    case 2:
                        mToolbarTitle.setText("Hospital Report");
                        break;
                    case 3:
                        mToolbarTitle.setText("Shop");
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        //a listener on toolbarImage
        mToolbarImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (FirebaseAuth.getInstance().getCurrentUser()==null){
                    //if not login then call login activity
                    startActivity(new Intent(MainActivity.this,Login.class));
                }
                else{
                    //then call profileActivity
                    Intent profileIntent=new Intent(MainActivity.this,UserProfile.class);
                    ActivityOptionsCompat optionsCompat=ActivityOptionsCompat.makeSceneTransitionAnimation(MainActivity.this
                    ,mToolbarImage, mToolbarImage.getTransitionName());
                    profileIntent.putExtra("user",mCurrentUser);
                    startActivity(profileIntent,optionsCompat.toBundle());
                }
            }
        });
        setTabView();
    }

    /***
     * A custom ViewPager Adapter class,to handle the tabs
     */
    private class MyViewpagerAdapter extends FragmentPagerAdapter {

        public MyViewpagerAdapter(@NonNull FragmentManager fm, int behavior) {
            super(fm, behavior);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0:
                    return new InfoFragment();
                case 1:
                    return new HealthFragment();
                case 2:
                    return new ReportFragment();
                case 3:
                    return new ShopFragment();
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return 4;
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position){
                case 0:
                    return "INFO";
                case 1:
                    return "HEALTH SCORE";
                case 2:
                    return "REPORT";
                case 3:
                    return "Shop";
            }
            return super.getPageTitle(position);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUserImage();
        cartImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cart=new Intent(MainActivity.this,CartActivity.class);
                ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(MainActivity.this,cartImg,cartImg.getTransitionName());
                startActivity(cart,options.toBundle());
            }
        });
    }

    /***
     * set a image on toolbarImage
     */
    private void setUserImage(){
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if (user!=null){
            Uri picuri=user.getPhotoUrl();
            if (picuri==null){
                mToolbarImage.setImageDrawable(getDrawable(R.drawable.ic_baseline_account_circle_24));
            }else{
                Picasso.get().load(picuri).into(mToolbarImage);
            }
        }else {
            mToolbarImage.setImageDrawable(getDrawable(R.drawable.ic_baseline_account_circle_24));
        }
    }

    private void setTabView(){
        /*View view=LayoutInflater.from(this).inflate(R.layout.custom_tab_layout, null);
        TextView tabText = view.findViewById(R.id.tab_textView_custom_tab);
        *//*for (int i=0;i<mTabLayout.getTabCount();i++){
            switch (i){
                case 0:
                    tabText.setText("Info");
                    break;
                case 1:
                    tabText.setText("Health Score ");
                    break;
                case 2:
                    tabText.setText("Hospital Report");
                    break;
            }
           Objects.requireNonNull(mTabLayout.getTabAt(i)).setCustomView(view);
        }*//*
        tabText.setText("Info");
        mTabLayout.getTabAt(0).setCustomView(view);
        tabText.setText("Health Score");
        mTabLayout.getTabAt(1).setCustomView(view);
        tabText.setText("Hospital Report");
        mTabLayout.getTabAt(2).setCustomView(view);*/
        for (int i=0;i<mTabLayout.getTabCount();i++){
            mTabLayout.getTabAt(i).setCustomView(getLayoutInflater().inflate(R.layout.custom_tab_layout,null));
            LottieAnimationView animationView=null;
            switch (i){
                case 0:
                    animationView=mTabLayout.getTabAt(i).getCustomView().findViewById(android.R.id.icon);
                    animationView.setAnimationFromUrl("https://assets3.lottiefiles.com/packages/lf20_98zCnL/47 - Information.json");
                    break;
                case 1:
                    animationView=mTabLayout.getTabAt(i).getCustomView().findViewById(android.R.id.icon);
                    animationView.setAnimationFromUrl("https://assets4.lottiefiles.com/packages/lf20_ZKUJ2j.json");
                    break;
                case 2:
                    animationView=mTabLayout.getTabAt(i).getCustomView().findViewById(android.R.id.icon);
                    animationView.setAnimationFromUrl("https://assets10.lottiefiles.com/packages/lf20_jpgowcl7.json");
                    break;
                case 3:
                    animationView=mTabLayout.getTabAt(i).getCustomView().findViewById(android.R.id.icon);
                    animationView.setAnimationFromUrl("https://assets5.lottiefiles.com/packages/lf20_1OPxxN.json");
                    break;
            }
            animationView.setVisibility(View.VISIBLE);
            //animationView.playAnimation();
        }

    }

    private void fetchUser(){
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if (user==null) return;
        FirebaseFirestore.getInstance().collection("User")
                .whereEqualTo("uid",user.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot snapshot:task.getResult()){
                                mCurrentUser=snapshot.toObject(User.class);
                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                e.printStackTrace();
                Log.e("Mainactivity","user data not found.."+e.getMessage());
            }
        });
    }


}